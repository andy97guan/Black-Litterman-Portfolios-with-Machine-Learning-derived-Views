# -*- coding: utf-8 -*-
"""
Author: Yifei Zhang
E-mail:dzhang97@bu.edu
"""
# 
# Q3task1.py - Question Set 3, Task 1
#
#  Volatility Experiments
# 

import pandas as pd
import pandas_datareader.data as web
import datetime
import numpy as np
import matplotlib.pyplot as plt
import math
import scipy.stats
from scipy.optimize import minimize

def Markowitz(wlen,r):
    # wlen is the length of lookback
    # r is the return matrix
    length=len(r)
    ticker=['efa','eem','gld','iyr']
    weights=pd.DataFrame(0,index=r.index[wlen:length],columns=ticker)
    ret=pd.DataFrame(0,index=r.index[wlen:length],columns=['MAR'])
    for i in range(wlen,length):
        X=np.mat(r.iloc[i-wlen:i,:].values)
        mean=np.mat(np.mean(X,axis=0)).T
        sigma=X.T*X
        weight=(np.linalg.inv(sigma)*mean).T
        weight=weight/np.sum(weight)/10
        weights.iloc[i-wlen,:]=np.array(weight)[0]
    ret.iloc[0:length-wlen]=np.diag(r.iloc[wlen:length].values*np.mat(weights).T)
    cumulative=ret.cumsum()
    cumulative=pd.DataFrame(cumulative,index=ret.index)
    return cumulative


def MomentumBlack(wlen,r,lam):
    # wlen is the length of lookback
    # r is the return matrix
    # lam is the risk aversion coefficient
    length=len(r)
    ticker=['efa','eem','gld','iyr']
    weights=pd.DataFrame(0,index=r.index[wlen:length],columns=ticker)
    ret=pd.DataFrame(0,index=r.index[wlen:length],columns=['MAR'])
    for i in range(wlen,length):
        X=np.mat(r.iloc[i-wlen:i,:].values)
        sigma=X.T*X
        Q=np.mat(r.iloc[i-1,:].values).T
        pi=lam*sigma*np.mat([61.72,26.92,42.03,4.56]).T/135.23
        mean=np.linalg.inv((np.linalg.inv(sigma)+2*np.identity(4)))*(np.linalg.inv(sigma)*pi+2*Q)
        weight=(np.linalg.inv(sigma)*mean).T
        weight=weight/np.sum(weight)
        weights.iloc[i-wlen,:]=np.array(weight)[0]
    ret.iloc[0:length-wlen]=np.diag(r.iloc[wlen:length].values*np.mat(weights).T)
    cumulative=ret.cumsum()
    cumulative=pd.DataFrame(cumulative,index=ret.index)
    return cumulative

def Backtest(r):
    # wlen is the length of lookback
    # r is the return matrix
    ticker=['efa','eem','gld','iyr']
    weights=pd.DataFrame(0,index=r.index,columns=ticker)
    ret=pd.DataFrame(0,index=r.index,columns=['BL'])
    weights=r.iloc[:,4:8]
    ret=np.diag(r.iloc[:,0:4].values*np.mat(weights).T)
    cumulative=ret.cumsum()
    cumulative=pd.DataFrame(cumulative,index=r.index)
    return cumulative

def Statistics(data):
    ticker=['Equal_Weighted','Marketcapital_Weighted','Momentum BL','Machine Learning BL','Markowitz']
    tlen=len(ticker)
    ticker1=['Mean p.a (%)','SD p.a (%)','Skewness','Kurtosis','VaR','CVaR','Sharpe Ratio','Omega','MDD']
    Table=pd.DataFrame(0,index=range(tlen),columns=ticker1)
    for i in range(tlen):
        Table.iloc[i,0]=np.mean(data[i].diff()[1:-1],axis=0)[0]*25200
    for i in range(tlen):
        Table.iloc[i,1]=np.std(data[i].diff()[1:-1],axis=0)[0]*math.sqrt(252)*100
    for i in range(tlen):
        Table.iloc[i,2]=scipy.stats.skew(data[i].diff()[1:-1],axis=0)[0]
    for i in range(tlen):
        Table.iloc[i,3]=scipy.stats.kurtosis(data[i].diff()[1:-1],axis=0)[0]
    for i in range(tlen):
        Table.iloc[i,4]=np.percentile(data[i].diff()[1:-1],5)
    for i in range(tlen):
        Var=np.percentile(data[i].diff()[1:-1],5)
        Table.iloc[i,5]=np.mean(data[i][data[i].iloc[:,0]<Var],axis=0)[0]
    for i in range(tlen):
        Table.iloc[i,6]=Table.iloc[i,0]/Table.iloc[i,1]
    for i in range(tlen):
        Table.iloc[i,7]=(-1)*np.mean(data[i][data[i].iloc[:,0]>0],axis=0)[0]/np.mean(data[i][data[i].iloc[:,0]<0],axis=0)[0]
    for i in range(tlen):
        Table.iloc[i,8]=np.max(np.maximum.accumulate(data[i])-data[i])[0]
    return Table
 
    

def fun(expret,sigma):
    [e0,e1,e2,e3]=expret
    a=1
    v=lambda x: -(e0*x[0]+e1*x[1]+e2*x[2]+e3*x[3])+a*np.mat([x[0],x[1],x[2],x[3]])*sigma*np.mat([x[0],x[1],x[2],x[3]]).T
    return v

def con(args):
    x0min,x0max,x1min, x1max, x2min, x2max,x3min,x3max = args  
    cons = ({'type': 'ineq', 'fun': lambda x: x[0]+x[1]+x[2]+x[3]-1},
             {'type': 'ineq', 'fun': lambda x: -(x[0]+x[1]+x[2]+x[3])+1},
            {'type': 'ineq', 'fun': lambda x: x[0] - x0min},     
             {'type': 'ineq', 'fun': lambda x: -x[0] + x0max}, 
            {'type': 'ineq', 'fun': lambda x: x[1] - x1min},     
             {'type': 'ineq', 'fun': lambda x: -x[1] + x1max},     
             {'type': 'ineq', 'fun': lambda x: x[2] - x2min},
             {'type': 'ineq', 'fun': lambda x: -x[2] + x2max},    
             {'type': 'ineq', 'fun': lambda x: x[3] - x3min},  
             {'type': 'ineq', 'fun': lambda x: -x[3] + x3max})
    return cons 


def PerfectBlack(wlen,r,lam):
    # wlen is the length of lookback
    # r is the return matrix
    length=len(r)
    ticker=['efa','eem','gld','iyr']
    weights=pd.DataFrame(0,index=r.index[wlen:length],columns=ticker)
    ret=pd.DataFrame(0,index=r.index[wlen:length],columns=['MAR'])
    for i in range(wlen,length):
        X=np.mat(r.iloc[i-wlen:i,:].values)
        sigma=X.T*X
        x0=np.asarray((0.25,0.25,0.25,0.25))
        cons=con((-1,1,-1,1,-1,1,-1,1))
        
        Q=np.mat(r.iloc[i,:].values).T
        pi=lam*sigma*np.mat([61.72,26.92,42.03,4.56]).T/135.23
        mean=np.linalg.inv((np.linalg.inv(sigma)+2*np.identity(4)))*(np.linalg.inv(sigma)*pi+2*Q)
        mean=mean.T
        res = minimize(fun(mean,sigma), x0, method='SLSQP',constraints=cons)
        weight=res.x
        weight=weight/np.sum(weight)
        weights.iloc[i-wlen,:]=np.array(weight)
    ret.iloc[0:length-wlen]=np.diag(r.iloc[wlen:length].values*np.mat(weights).T)
    cumulative=ret.cumsum()
    cumulative=pd.DataFrame(cumulative,index=ret.index)
    return cumulative









start=datetime.datetime(2008, 1, 1)
end=datetime.datetime(2019,11,1)

efa = web.DataReader("EFA", "yahoo", start, end).loc[:,'Adj Close']
eem = web.DataReader("EEM", "yahoo", start, end).loc[:,'Adj Close']
gld = web.DataReader("GLD", "yahoo", start, end).loc[:,'Adj Close']
iyr = web.DataReader("IYR", "yahoo", start, end).loc[:,'Adj Close']
efa.name='efa'
eem.name='eem'
gld.name='gld'
iyr.name='iyr'
a=pd.concat([efa,eem,gld,iyr],axis=1,join='inner')    #list of data for all ETFs 
ticker=['efa','eem','gld','iyr'] #ETF name list
l=int((a.index[-1]-a.index[0]).days)
length=len(a)
r=pd.DataFrame(0,index=a.index[1:length],columns=ticker)  #used to contain daily return 
for i in range(4):
    temp=a.iloc[:,i]
    r.iloc[:,i]=np.log(np.array(temp.iloc[1:length])/np.array(a.iloc[0:length-1,i]))
Equal_Weighted=pd.DataFrame(0,index=a.index[1:length],columns=['EW'])
Equal_Weighted=pd.DataFrame(np.mean(r,axis=1).cumsum())
MWret=np.mat(r)*np.mat([61.72,26.92,42.03,4.56]).T/135.23
Marketcapital_Weighted=pd.DataFrame(MWret,index=a.index[1:length],columns=['MW']).cumsum()
csv=r'C:\Users\lenovo\Desktop\MF803\project\weight_mvo(2).csv'
Markow=pd.read_csv(csv, header=0, sep=None,dtype={'time':str, 'close': np.float64 }, engine='python')
Markow.index=pd.to_datetime(Markow['Date'],format='%Y-%m-%d')
Markow=Markow.drop(['Date'],axis=1)
Markow=pd.concat([r,Markow],join='inner',axis=1,join_axes=[Markow.index])
Markow=Markow.dropna(axis=0,how='any')
Mark=Backtest(Markow)
Mbl=MomentumBlack(126,r,2.49)
csv1=r'C:\Users\lenovo\Desktop\MF803\project\weight(2).csv'
Blweights=pd.read_csv(csv1, header=0, sep=None,dtype={'time':str, 'close': np.float64 }, engine='python')
Blweights.index=pd.to_datetime(Blweights['Date'],format='%Y-%m-%d')
Blweights=Blweights.drop(['Date'],axis=1)
Blweights=pd.concat([r,Blweights],join='inner',axis=1,join_axes=[Blweights.index])
Blweights=Blweights.dropna(axis=0,how='any')
Bl=Backtest(Blweights)
Pbl=PerfectBlack(126,r,2.49)

plt.figure()
plt.plot(Equal_Weighted,label='Equal_Weighted')
plt.plot(Marketcapital_Weighted,label='Marketcapital_Weighted')
plt.plot(Mbl,label='Momentum BL')
plt.plot(Mark,label='Mean-Variance')
plt.plot(Bl,label='Machine Learning BL')
plt.plot(Pbl,label='Perfect BL')
plt.title("Cumulative Return")
plt.legend(loc='upper left')

temp=[Equal_Weighted,Marketcapital_Weighted,Mbl,Bl,Mark]
Table=Statistics(temp)

#def Markowitz(wlen,r):
#    # wlen is the length of lookback
#    # r is the return matrix
#    length=len(r)
#    ticker=['efa','eem','gld','iyr']
#    weights=pd.DataFrame(0,index=r.index[wlen:length],columns=ticker)
#    ret=pd.DataFrame(0,index=r.index[wlen:length],columns=['MAR'])
#    for i in range(wlen,length):
#        X=np.mat(r.iloc[i-wlen:i,:].values)
#        mean=np.mat(np.mean(X,axis=0)).T
#        sigma=X.T*X
#        weight=(np.linalg.inv(sigma)*mean).T
#        weight=weight/np.sum(weight)/10
#        weights.iloc[i-wlen,:]=np.array(weight)[0]
#    ret.iloc[0:length-wlen]=np.diag(r.iloc[wlen:length].values*np.mat(weights).T)
#    cumulative=ret.cumsum()
#    cumulative=pd.DataFrame(cumulative,index=ret.index)
#    return cumulative
#
#
#def MomentumBlack(wlen,r,lam):
#    # wlen is the length of lookback
#    # r is the return matrix
#    # lam is the risk aversion coefficient
#    length=len(r)
#    ticker=['efa','eem','gld','iyr']
#    weights=pd.DataFrame(0,index=r.index[wlen:length],columns=ticker)
#    ret=pd.DataFrame(0,index=r.index[wlen:length],columns=['MAR'])
#    for i in range(wlen,length):
#        X=np.mat(r.iloc[i-wlen:i,:].values)
#        sigma=X.T*X
#        Q=np.mat(r.iloc[i-1,:].values).T
#        pi=lam*sigma*np.mat([61.72,26.92,42.03,4.56]).T/135.23
#        mean=np.linalg.inv((np.linalg.inv(sigma)+2*np.identity(4)))*(np.linalg.inv(sigma)*pi+2*Q)
#        weight=(np.linalg.inv(sigma)*mean).T
#        weight=weight/np.sum(weight)
#        weights.iloc[i-wlen,:]=np.array(weight)[0]
#    ret.iloc[0:length-wlen]=np.diag(r.iloc[wlen:length].values*np.mat(weights).T)
#    cumulative=ret.cumsum()
#    cumulative=pd.DataFrame(cumulative,index=ret.index)
#    return cumulative
#
#def Backtest(r):
#    # wlen is the length of lookback
#    # r is the return matrix
#    ticker=['efa','eem','gld','iyr']
#    weights=pd.DataFrame(0,index=r.index,columns=ticker)
#    ret=pd.DataFrame(0,index=r.index,columns=['BL'])
#    weights=r.iloc[:,4:8]
#    ret=np.diag(r.iloc[:,0:4].values*np.mat(weights).T)
#    cumulative=ret.cumsum()
#    cumulative=pd.DataFrame(cumulative,index=r.index)
#    return cumulative
#
#def Statistics(data):
#    ticker=['Equal_Weighted','Marketcapital_Weighted','Momentum BL','Machine Learning BL','Markowitz']
#    tlen=len(ticker)
#    ticker1=['Mean p.a (%)','SD p.a (%)','Skewness','Kurtosis','VaR','CVaR','Sharpe Ratio','Omega','MDD']
#    Table=pd.DataFrame(0,index=range(tlen),columns=ticker1)
#    for i in range(tlen):
#        Table.iloc[i,0]=np.mean(data[i].diff()[1:-1],axis=0)[0]*25200
#    for i in range(tlen):
#        Table.iloc[i,1]=np.std(data[i].diff()[1:-1],axis=0)[0]*math.sqrt(252)*100
#    for i in range(tlen):
#        Table.iloc[i,2]=scipy.stats.skew(data[i].diff()[1:-1],axis=0)[0]
#    for i in range(tlen):
#        Table.iloc[i,3]=scipy.stats.kurtosis(data[i].diff()[1:-1],axis=0)[0]
#    for i in range(tlen):
#        Table.iloc[i,4]=np.percentile(data[i].diff()[1:-1],5)
#    for i in range(tlen):
#        Var=np.percentile(data[i].diff()[1:-1],5)
#        Table.iloc[i,5]=np.mean(data[i][data[i].iloc[:,0]<Var],axis=0)[0]
#    for i in range(tlen):
#        Table.iloc[i,6]=Table.iloc[i,0]/Table.iloc[i,1]
#    for i in range(tlen):
#        Table.iloc[i,7]=(-1)*np.mean(data[i][data[i].iloc[:,0]>0],axis=0)[0]/np.mean(data[i][data[i].iloc[:,0]<0],axis=0)[0]
#    for i in range(tlen):
#        Table.iloc[i,8]=np.max(np.maximum.accumulate(data[i])-data[i])[0]
#    return Table
# 
#    
#
#def fun(expret,sigma):
#    [e0,e1,e2,e3]=expret
#    a=1
#    v=lambda x: -(e0*x[0]+e1*x[1]+e2*x[2]+e3*x[3])+a*np.mat([x[0],x[1],x[2],x[3]])*sigma*np.mat([x[0],x[1],x[2],x[3]]).T
#    return v
#
#def con(args):
#    x0min,x0max,x1min, x1max, x2min, x2max,x3min,x3max = args  
#    cons = ({'type': 'ineq', 'fun': lambda x: x[0]+x[1]+x[2]+x[3]-1},
#             {'type': 'ineq', 'fun': lambda x: -(x[0]+x[1]+x[2]+x[3])+1},
#            {'type': 'ineq', 'fun': lambda x: x[0] - x0min},     
#             {'type': 'ineq', 'fun': lambda x: -x[0] + x0max}, 
#            {'type': 'ineq', 'fun': lambda x: x[1] - x1min},     
#             {'type': 'ineq', 'fun': lambda x: -x[1] + x1max},     
#             {'type': 'ineq', 'fun': lambda x: x[2] - x2min},
#             {'type': 'ineq', 'fun': lambda x: -x[2] + x2max},    
#             {'type': 'ineq', 'fun': lambda x: x[3] - x3min},  
#             {'type': 'ineq', 'fun': lambda x: -x[3] + x3max})
#    return cons 
#
#
#def PerfectBlack(wlen,r,lam):
#    # wlen is the length of lookback
#    # r is the return matrix
#    length=len(r)
#    ticker=['efa','eem','gld','iyr']
#    weights=pd.DataFrame(0,index=r.index[wlen:length],columns=ticker)
#    ret=pd.DataFrame(0,index=r.index[wlen:length],columns=['MAR'])
#    for i in range(wlen,length):
#        X=np.mat(r.iloc[i-wlen:i,:].values)
#        sigma=X.T*X
#        x0=np.asarray((0.25,0.25,0.25,0.25))
#        cons=con((-1,1,-1,1,-1,1,-1,1))
#        
#        Q=np.mat(r.iloc[i,:].values).T
#        pi=lam*sigma*np.mat([61.72,26.92,42.03,4.56]).T/135.23
#        mean=np.linalg.inv((np.linalg.inv(sigma)+2*np.identity(4)))*(np.linalg.inv(sigma)*pi+2*Q)
#        mean=mean.T
#        res = minimize(fun(mean,sigma), x0, method='SLSQP',constraints=cons)
#        weight=res.x
#        weight=weight/np.sum(weight)
#        weights.iloc[i-wlen,:]=np.array(weight)
#    ret.iloc[0:length-wlen]=np.diag(r.iloc[wlen:length].values*np.mat(weights).T)
#    cumulative=ret.cumsum()
#    cumulative=pd.DataFrame(cumulative,index=ret.index)
#    return cumulative
#
#
#















#
#def fun(args):
#    a,b,c,d=args
#    v=lambda x: np.mat([x[0],x[1],x[2]])*np.mat([x[0],x[1],x[2]]).T
#    return v
#
#def con(args):
#    x1min, x1max, x2min, x2max,x3min,x3max = args  
#    cons = ({'type': 'ineq', 'fun': lambda x: x[0] - x1min},     
#             {'type': 'ineq', 'fun': lambda x: -x[0] + x1min},     
#             {'type': 'ineq', 'fun': lambda x: x[1] - x2min},
#             {'type': 'ineq', 'fun': lambda x: -x[1] + x2max},    
#             {'type': 'ineq', 'fun': lambda x: x[2] - x3min},  
#             {'type': 'ineq', 'fun': lambda x: -x[2] + x3max})
#    return cons 
#args = (2,1,3,4)
#args1 = (0.2,0.9,0.1, 0.9,0.1,0.9)
#cons = con(args1)
#x0 = np.asarray((0.5,0.5,0.5))
#res = minimize(fun(args), x0, method='SLSQP',constraints=cons)
#print(res.fun)
#print(res.success)
#print(res.x)    














        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        





